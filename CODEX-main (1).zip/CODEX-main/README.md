# CODEX 2026 – Hackathon Website

Official website for **CODEX 2026**, a 24-hour inter-college Gen AI hackathon organised at **TKM Institute of Technology, Kollam, Kerala** on **27–28 January 2026**.

Built with **JavaScript, HTML and CSS** (React + TypeScript, Tailwind CSS), featuring an interactive 3D background and scroll-driven animations. UI polished with **Google Antigravity**.

<!-- Add a screenshot here: ![CODEX 2026 homepage](docs/screenshot.png) -->

## Features

- Single-page site with **Home** and **Registration** views
- Animated loading screen and smooth scrolling (Lenis)
- Interactive **3D particle-network background** that reacts to mouse and touch (three.js / react-three-fiber)
- **Countdown timer** and an "Add to Google Calendar" link
- **Tracks** section with a problem-statement viewer (modal with expandable cards)
- Horizontal **event timeline** driven by vertical scroll
- Prizes, sponsors (logos auto-loaded from a folder) and FAQ sections
- Custom animated cursor and text effects
- Hidden easter eggs (desktop only):
  - Konami code (↑ ↑ ↓ ↓ ← → ← → B A) opens an **Asteroids** game
  - Click the logo 5 times quickly for a **gravity playground** (matter-js physics)
  - Type `CREDITS.` to open the credits screen
- Registration handled through a Google Form

## Tech Stack

| Area | Tools |
|---|---|
| Core | JavaScript, HTML, CSS |
| Framework | React 18, TypeScript, Vite |
| Styling | Tailwind CSS, custom CSS |
| Animation | framer-motion, Lenis |
| 3D / physics | three.js, @react-three/fiber, @react-three/drei, matter-js |
| Icons | lucide-react |
| Deployment | Docker (multi-stage build), nginx |
| Tools | Google Antigravity (UI improvements), Git and GitHub |

## Project Structure

```
├── App.tsx              # App shell: loader, page switching, background, easter eggs
├── index.tsx            # React entry point
├── index.html           # HTML shell, Tailwind config, global styles
├── constants.ts         # Tracks, prizes, FAQs, sponsors, problem statements
├── types.ts             # TypeScript interfaces for the data
├── components/          # Hero, About, Tracks, Timeline, Prizes, Sponsors, FAQ, Footer...
│   ├── game/            # Asteroids game and gravity playground
│   └── ui/              # Reusable UI pieces (cursor, text effects, marquee...)
├── hooks/               # Konami code, word trigger and gravity trigger hooks
├── public/              # Images and partner logos
├── Dockerfile           # Multi-stage build (Node build, nginx serve)
└── nginx.conf           # SPA routing, gzip and caching
```




